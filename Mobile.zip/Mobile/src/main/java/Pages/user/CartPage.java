package Pages.user;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CartPage {
    private WebDriver driver;
    protected WebDriverWait wait;
    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    private By DatHangNgayButtonLocator = By.id("order_product");
    private By iconClose=By.xpath("//div[@id='cart_modal']//button[@type='button' and normalize-space()='×']");
    public void ClickOrderButton() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(DatHangNgayButtonLocator));
        driver.findElement(DatHangNgayButtonLocator).click();
    }
    public void CloseCartForm() {
        WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(iconClose));
        closeButton.click();
    }
    public By getDiscountByRow(int s) {
        return By.xpath("//table//tbody//tr[" + s + "]/td[3]");
    }

    public By getUnitPriceByRow(int s) {
        return By.xpath("//table//tbody//tr[" + s + "]/td[5]");
    }

    public By getSubtotalByRow(int s) {
        return By.xpath("//table//tbody//tr[" + s + "]/td[6]");
    }

    public int getQuantityAsIntByRow(int s) {
        WebElement selectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//table//tbody//tr[" + s + "]/td[4]//select")));
        Select select = new Select(selectElement);
        String selectedText = select.getFirstSelectedOption().getText().trim();
        return Integer.parseInt(selectedText);
    }

    // Lấy đơn giá
    public double getUnitPriceByRowAsDouble(int s) {
        String text = driver.findElement(getUnitPriceByRow(s)).getText().trim();
        return parseCurrencyToDouble(text);
    }

    // Lấy thành tiền
    public double getSubtotalByRowAsDouble(int s) {
        String text = driver.findElement(getSubtotalByRow(s)).getText().trim();
        return parseCurrencyToDouble(text);
    }

    // Lấy giảm giá
    public double getDiscountAsDouble(int s) {
        String text = driver.findElement(getDiscountByRow(s)).getText().trim();
        if (text.isEmpty()) {
            return 0.0;
        }
        return parsePercentToDouble(text);
    }

    // Tính expected subtotal
    public double calculateExpectedSubtotal(int s) {
        int quantity = getQuantityAsIntByRow(s);
        double unitPrice = getUnitPriceByRowAsDouble(s);
        double discount = getDiscountAsDouble(s);

        return ((100 - discount) / 100.0) * quantity * unitPrice;
    }

    // Kiểm tra expected subtotal với subtotal thực tế
    public boolean isSubtotalCorrect(int s) {
        int quantity = getQuantityAsIntByRow(s);
        double unitPrice = getUnitPriceByRowAsDouble(s);
        double discount = getDiscountAsDouble(s);
        double expected = ((100 - discount) / 100.0) * quantity * unitPrice;
        double actual = getSubtotalByRowAsDouble(s);

        // In ra chi tiết
//        System.out.println(" Dòng " + s + ": Số lượng = " + quantity + ", Đơn giá = " + unitPrice +
//                ", Giảm giá = " + discount + "%");
//        System.out.printf("Thành tiền mong đợi: ((100 - %.1f)/100) * %d * %.0f = %.2f\n",
//                discount, quantity, unitPrice, expected);
//        System.out.printf("Thành tiền thực tế: %.2f\n\n", actual);
//
       return expected == actual;
    }

    private double parseCurrencyToDouble(String text) {
        return Double.parseDouble(text.replace("đ", "").replace(".", "").replace(",", "").trim());
    }


    private double parsePercentToDouble(String text) {
        return Double.parseDouble(text.replace("%", "").trim());
    }


}
