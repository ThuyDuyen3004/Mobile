package utils;

public class Constants {
    public static String URL = "http://14.176.232.213/mobilevn/";
    public static String EMAIL = "leduyenduyen3004123@gmail.com";
    public static String PASSWORD = "3042004a3A@";

    // Admin credentials
    public static String URL_ADMIN = "http://14.176.232.213/mobilevn/admin/admin.php";
    public static String USERNAME_ADMIN = "tranthang212@gmail.com";
    public static String PASSWORD_ADMIN = "123456";
}
