package Test;

import Pages.user.*;
import jdk.jfr.Description;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import utils.Constants;

import java.time.Duration;

public class TC07 {
    WebDriver driver;
    WebDriverWait wait;
    SoftAssert softAssert;
    LoginPage loginPage;
    HomePage homePage;
    CartPage cartPage;
    OrderPage orderPage;
    PaymentPage paymentPage;
    SearchPage searchPage;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        softAssert = new SoftAssert();

        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        cartPage = new CartPage(driver);
        orderPage = new OrderPage(driver);
        paymentPage = new PaymentPage(driver);
        searchPage = new SearchPage(driver);

    }

    @Test
    @Description("Verify that the product list page correctly displays products that match the selected price filter options.")
    public void CheckFilterOptions() throws InterruptedException {
        driver.get(Constants.URL);
        homePage.OpenLoginForm();
        loginPage.login(Constants.EMAIL, Constants.PASSWORD);
        homePage.clickbutton();

        // Kiểm tra sắp xếp từ thấp đến cao
        homePage.clickXemthem();
        homePage.selectGiaThapDenCao();
        boolean isSorted1 = homePage.isSortedByGiaThapDenCao();
        softAssert.assertTrue(isSorted1, "Danh sách chưa được sắp xếp đúng theo giá từ thấp đến cao.");

        // Kiểm tra sắp xếp từ cao đến thấp
        homePage.clickXemthem();
        homePage.selectGiaCaoDenThap();
        boolean isSorted2 = homePage.isSortedByGiaCaoDenThap();
        softAssert.assertTrue(isSorted2, "Danh sách chưa được sắp xếp đúng theo giá từ cao đến thấp.");

        softAssert.assertAll();}
        @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
